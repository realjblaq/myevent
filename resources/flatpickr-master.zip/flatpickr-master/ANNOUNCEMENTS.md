# Announcements

This file will contain updates regarding the state of the project.

## 2018-08-06

Hey guys,

I have been busy with full time work this summer, so development has predicably slowed down.

I will be leaning more on community contributions until the pace picks up in September when I finish my work term and am back to university studies.
 
Thank you all for your patience and understanding.
